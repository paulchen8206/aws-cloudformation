#!/bin/bash
rm -rf /usr/share/tomcat8/webapps/ccdemo*
